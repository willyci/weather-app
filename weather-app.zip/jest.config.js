// export default {
//     preset: 'ts-jest',
//     testEnvironment: 'jsdom',
//     setupFilesAfterEnv: ['@testing-library/jest-dom/extend-expect'],
//     testEnvironment: 'jest-environment-jsdom',
//   };